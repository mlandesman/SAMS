#!/usr/bin/env node

/**
 * HOA Dues Import Script for Production Import
 * 
 * This script imports HOA dues with transaction linking:
 * - Parses payment notes for payment data
 * - Links HOA dues to transactions via sequence numbers
 * - Handles positive amounts for income classification
 * - Generates proper document IDs for HOA dues
 * 
 * Usage: node 06-hoa-dues-import.js
 */

import { initializeFirebase, getDb } from '../../firebase.js';
import admin from 'firebase-admin';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CLIENT_ID = 'MTC';
const CURRENT_YEAR = '2025';

console.log(`🚀 Starting HOA Dues Import with Transaction Linking`);
console.log(`🏢 Client: ${CLIENT_ID}`);
console.log(`📅 Year: ${CURRENT_YEAR}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

// Helper function to parse payment notes
function parsePaymentNotes(notes) {
  if (!notes || typeof notes !== 'string') {
    return {
      paymentDate: null,
      sequenceNumber: null,
      originalAmount: null,
      paymentMethod: null
    };
  }
  
  try {
    // Extract payment date: "Posted: MXN 15,000.00 on Sat Dec 28 2024 13:56:50 GMT-0500"
    const dateMatch = notes.match(/on\s+(.+?)\s+GMT/);
    const paymentDate = dateMatch ? dateMatch[1] : null;
    
    // Extract sequence number: "Seq: 25010"
    const seqMatch = notes.match(/Seq:\s*(\d+)/);
    const sequenceNumber = seqMatch ? seqMatch[1] : null;
    
    // Extract original amount: "MXN 15,000.00"
    const amountMatch = notes.match(/MXN\s+([\d,]+\.?\d*)/);
    const originalAmount = amountMatch ? amountMatch[1] : null;
    
    // Extract payment method from months line (e.g., "Jan, Feb, Mar 2025; HSBC")
    const methodMatch = notes.match(/;\s*([A-Z]+)/);
    const paymentMethod = methodMatch ? methodMatch[1] : null;
    
    return {
      paymentDate,
      sequenceNumber,
      originalAmount,
      paymentMethod
    };
    
  } catch (error) {
    console.warn(`Error parsing payment notes: ${error.message}`);
    return {
      paymentDate: null,
      sequenceNumber: null,
      originalAmount: null,
      paymentMethod: null
    };
  }
}

// Helper function to convert dollars to centavos
function dollarsToCentavos(amount) {
  if (typeof amount !== 'number' || isNaN(amount)) {
    console.warn(`Invalid amount for conversion: ${amount}`);
    return 0;
  }
  
  return Math.round(amount * 100);
}

// Helper function to generate HOA due document ID
function generateHOADueId(unitId, month, year = CURRENT_YEAR) {
  return `${unitId}_${year}_${String(month).padStart(2, '0')}`;
}

// Helper function to parse date from notes
function parseDate(dateString) {
  if (!dateString) {
    return null;
  }
  
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      console.warn(`Invalid date: ${dateString}`);
      return null;
    }
    return date;
  } catch (error) {
    console.warn(`Error parsing date: ${dateString} - ${error.message}`);
    return null;
  }
}

// Helper function to get month name
function getMonthName(month) {
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  
  return monthNames[month - 1] || `Month ${month}`;
}

async function loadHOADuesData() {
  console.log(`📖 Loading HOA dues data`);
  
  try {
    // Load from MTCdata directory
    const hoaDuesPath = join(__dirname, '../../../MTCdata/HOADues.json');
    const hoaDuesData = JSON.parse(readFileSync(hoaDuesPath, 'utf8'));
    
    console.log(`✅ Loaded HOA dues data for ${Object.keys(hoaDuesData).length} units`);
    
    // Sample first few units for validation
    const unitIds = Object.keys(hoaDuesData).slice(0, 3);
    console.log(`📋 Sample units:`);
    unitIds.forEach((unitId, index) => {
      const unit = hoaDuesData[unitId];
      console.log(`   ${index + 1}. Unit ${unitId}: ${unit.payments?.length || 0} payments`);
    });
    
    return hoaDuesData;
    
  } catch (error) {
    console.error(`❌ Error loading HOA dues data:`, error);
    throw error;
  }
}

async function importHOADuesComplete() {
  console.log(`🏠 Starting HOA dues import with payment data`);
  
  try {
    const hoaDuesData = await loadHOADuesData();
    const db = await getDb();
    
    let importedCount = 0;
    let skippedCount = 0;
    let linkedCount = 0;
    const importedHOADues = [];
    
    for (const [unitId, unitData] of Object.entries(hoaDuesData)) {
      if (!unitData.payments || !Array.isArray(unitData.payments)) {
        console.log(`   ⚠️  Skipping unit ${unitId}: No payments data`);
        skippedCount++;
        continue;
      }
      
      console.log(`   📋 Processing unit ${unitId}: ${unitData.payments.length} payments`);
      
      // FIX 1: Use correct collection path - store under unit's dues subcollection
      const unitDuesRef = db.collection(`clients/${CLIENT_ID}/units/${unitId}/dues`);
      
      // Create year document with payments array (following HOA dues pattern)
      const paymentsArray = new Array(12).fill(null);
      const yearData = {
        year: parseInt(CURRENT_YEAR),
        unitId: unitId,
        clientId: CLIENT_ID,
        creditBalance: unitData.creditBalance || 0,
        totalPaid: unitData.totalPaid || 0,
        outstanding: unitData.outstanding || 0,
        scheduledAmount: unitData.scheduledAmount || 0,
        payments: paymentsArray,
        
        // Metadata
        metadata: {
          source: 'production-import-package',
          importDate: admin.firestore.FieldValue.serverTimestamp(),
          originalData: {
            unitId: unitId,
            creditBalance: unitData.creditBalance,
            totalPaid: unitData.totalPaid,
            outstanding: unitData.outstanding
          },
          autoGenerated: true
        },
        
        // Audit fields
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        createdBy: 'production-import-setup',
        lastModified: admin.firestore.FieldValue.serverTimestamp(),
        lastModifiedBy: 'production-import-setup'
      };
      
      // Process each payment and add to payments array
      for (const payment of unitData.payments) {
        if (!payment.month || !payment.paid) {
          console.log(`   ⚠️  Skipping invalid payment for unit ${unitId}: ${JSON.stringify(payment)}`);
          skippedCount++;
          continue;
        }
        
        try {
          // Parse payment notes
          const parsedNotes = parsePaymentNotes(payment.notes);
          
          // Convert amount to centavos (positive for income)
          const amountCentavos = Math.abs(dollarsToCentavos(payment.paid));
          
          // Create due date (first of the month)
          const dueDate = new Date(parseInt(CURRENT_YEAR), payment.month - 1, 1);
          
          // Parse payment date from notes
          const paymentDate = parseDate(parsedNotes.paymentDate);
          
          // Build payment data for array
          const paymentData = {
            month: payment.month,
            monthName: getMonthName(payment.month),
            amount: amountCentavos, // Positive for income
            currency: 'MXN',
            scheduledAmount: dollarsToCentavos(unitData.scheduledAmount || payment.paid),
            
            // Payment information
            dueDate: dueDate,
            paymentDate: paymentDate,
            status: paymentDate ? 'paid' : 'pending',
            
            // Transaction linking
            sequenceNumber: parsedNotes.sequenceNumber,
            transactionId: null, // Will be linked later
            
            // Payment details
            paymentMethod: parsedNotes.paymentMethod,
            originalAmount: parsedNotes.originalAmount,
            
            // Notes
            notes: payment.notes || '',
            
            // Original data
            originalData: {
              month: payment.month,
              paid: payment.paid,
              notes: payment.notes
            },
            parsedNotes: parsedNotes
          };
          
          // Add to payments array (month 1 = index 0)
          paymentsArray[payment.month - 1] = paymentData;
          
          importedHOADues.push({
            id: `${unitId}_${CURRENT_YEAR}_${String(payment.month).padStart(2, '0')}`,
            unitId: unitId,
            month: payment.month,
            amount: amountCentavos,
            sequenceNumber: parsedNotes.sequenceNumber,
            hasSequence: !!parsedNotes.sequenceNumber,
            paymentDate: paymentDate,
            paymentMethod: parsedNotes.paymentMethod
          });
          
          importedCount++;
          
        } catch (error) {
          console.error(`   ❌ Error processing payment for unit ${unitId}, month ${payment.month}:`, error);
          skippedCount++;
        }
      }
      
      // Save year document with all payments
      try {
        await unitDuesRef.doc(CURRENT_YEAR).set(yearData);
        console.log(`   ✅ Saved HOA dues for unit ${unitId} (year ${CURRENT_YEAR})`);
      } catch (error) {
        console.error(`   ❌ Error saving HOA dues for unit ${unitId}:`, error);
        skippedCount++;
      }
    }
    
    console.log(`✅ HOA dues import completed`);
    console.log(`📊 Import Summary:`);
    console.log(`   - Total units processed: ${Object.keys(hoaDuesData).length}`);
    console.log(`   - Successfully imported: ${importedCount}`);
    console.log(`   - Skipped: ${skippedCount}`);
    console.log(`   - With sequence numbers: ${importedHOADues.filter(hoa => hoa.hasSequence).length}`);
    console.log(`   - With payment dates: ${importedHOADues.filter(hoa => hoa.paymentDate).length}`);
    
    return importedHOADues;
    
  } catch (error) {
    console.error(`❌ HOA dues import failed:`, error);
    throw error;
  }
}

async function linkHOADuesToTransactions() {
  console.log(`🔗 Starting transaction linking process`);
  
  try {
    const db = await getDb();
    const transactionsRef = db.collection(`clients/${CLIENT_ID}/transactions`);
    
    // Get all transactions
    const transactionsSnapshot = await transactionsRef.get();
    const transactionLookup = {};
    
    // Build transaction lookup by sequence number
    transactionsSnapshot.forEach(doc => {
      const data = doc.data();
      const notes = data.notes || '';
      
      // Extract sequence number from transaction notes
      const seqMatch = notes.match(/Seq:\s*(\d+)/);
      if (seqMatch) {
        const sequenceNumber = seqMatch[1];
        transactionLookup[sequenceNumber] = doc.id;
      }
    });
    
    console.log(`📋 Found ${Object.keys(transactionLookup).length} transactions with sequence numbers`);
    
    // FIX 1: Process HOA dues from correct location - under units subcollection
    const unitsRef = db.collection(`clients/${CLIENT_ID}/units`);
    const unitsSnapshot = await unitsRef.get();
    
    let linkedCount = 0;
    let unlinkableCount = 0;
    let totalPayments = 0;
    
    for (const unitDoc of unitsSnapshot.docs) {
      const unitId = unitDoc.id;
      
      try {
        // Get unit's dues year document
        const unitDuesRef = db.collection(`clients/${CLIENT_ID}/units/${unitId}/dues`);
        const yearDoc = await unitDuesRef.doc(CURRENT_YEAR).get();
        
        if (yearDoc.exists) {
          const yearData = yearDoc.data();
          
          if (yearData.payments && Array.isArray(yearData.payments)) {
            let unitLinkedCount = 0;
            const updatedPayments = yearData.payments.map(payment => {
              if (payment && payment.sequenceNumber) {
                totalPayments++;
                
                if (transactionLookup[payment.sequenceNumber]) {
                  const transactionId = transactionLookup[payment.sequenceNumber];
                  payment.transactionId = transactionId;
                  unitLinkedCount++;
                  linkedCount++;
                  return payment;
                } else {
                  unlinkableCount++;
                  return payment;
                }
              }
              return payment;
            });
            
            // Update year document with linked transactions
            if (unitLinkedCount > 0) {
              await yearDoc.ref.update({
                payments: updatedPayments,
                lastModified: admin.firestore.FieldValue.serverTimestamp(),
                lastModifiedBy: 'production-import-linking'
              });
              
              console.log(`   ✅ Unit ${unitId}: ${unitLinkedCount} payments linked`);
            }
          }
        }
      } catch (error) {
        console.error(`   ❌ Error linking unit ${unitId}:`, error);
      }
    }
    
    console.log(`✅ Transaction linking completed`);
    console.log(`📊 Linking Summary:`);
    console.log(`   - Total payments processed: ${totalPayments}`);
    console.log(`   - Successfully linked: ${linkedCount}`);
    console.log(`   - Unable to link: ${unlinkableCount}`);
    console.log(`   - Link rate: ${totalPayments > 0 ? ((linkedCount / totalPayments) * 100).toFixed(1) : 0}%`);
    
    return { linkedCount, unlinkableCount };
    
  } catch (error) {
    console.error(`❌ Transaction linking failed:`, error);
    throw error;
  }
}

async function validateHOADuesImport() {
  console.log(`🔍 Validating HOA dues import`);
  
  try {
    const db = await getDb();
    
    // FIX 1: Validate HOA dues in correct location - under units subcollection
    const unitsRef = db.collection(`clients/${CLIENT_ID}/units`);
    const unitsSnapshot = await unitsRef.get();
    
    let validUnits = 0;
    let invalidUnits = 0;
    let totalAmount = 0;
    let linkedPayments = 0;
    let totalPayments = 0;
    
    for (const unitDoc of unitsSnapshot.docs) {
      const unitId = unitDoc.id;
      
      try {
        // Check if unit has dues subcollection with year document
        const unitDuesRef = db.collection(`clients/${CLIENT_ID}/units/${unitId}/dues`);
        const yearDoc = await unitDuesRef.doc(CURRENT_YEAR).get();
        
        if (yearDoc.exists) {
          const yearData = yearDoc.data();
          
          if (yearData.unitId && yearData.payments && Array.isArray(yearData.payments)) {
            validUnits++;
            
            // Count payments and calculate totals
            yearData.payments.forEach(payment => {
              if (payment) {
                totalPayments++;
                totalAmount += payment.amount || 0;
                
                if (payment.transactionId) {
                  linkedPayments++;
                }
              }
            });
            
            console.log(`   ✅ Unit ${unitId}: ${yearData.payments.filter(p => p !== null).length} payments found`);
          } else {
            invalidUnits++;
            console.log(`   ⚠️  Unit ${unitId}: Invalid year document structure`);
          }
        } else {
          invalidUnits++;
          console.log(`   ⚠️  Unit ${unitId}: No year document found`);
        }
      } catch (error) {
        invalidUnits++;
        console.log(`   ❌ Unit ${unitId}: Validation error - ${error.message}`);
      }
    }
    
    console.log(`✅ Validation: ${validUnits} units with HOA dues found`);
    console.log(`📊 Validation Summary:`);
    console.log(`   - Valid units: ${validUnits}`);
    console.log(`   - Invalid units: ${invalidUnits}`);
    console.log(`   - Total payments: ${totalPayments}`);
    console.log(`   - Linked to transactions: ${linkedPayments}`);
    console.log(`   - Total amount: $${(totalAmount / 100).toFixed(2)} MXN`);
    console.log(`   - Success rate: ${validUnits > 0 ? ((validUnits / unitsSnapshot.size) * 100).toFixed(1) : 0}%`);
    console.log(`   - Link rate: ${totalPayments > 0 ? ((linkedPayments / totalPayments) * 100).toFixed(1) : 0}%`);
    
    return validUnits === unitsSnapshot.size;
    
  } catch (error) {
    console.error(`❌ HOA dues validation failed:`, error);
    return false;
  }
}

async function runHOADuesImport() {
  console.log(`🚀 Starting HOA dues import process`);
  
  try {
    // Step 1: Import HOA dues with payment data
    const importedHOADues = await importHOADuesComplete();
    
    // Step 2: Link HOA dues to transactions
    const linkingResult = await linkHOADuesToTransactions();
    
    // Step 3: Validate import
    const isValid = await validateHOADuesImport();
    
    if (isValid) {
      console.log(`✅ HOA dues import completed successfully`);
      console.log(`📊 Final Summary:`);
      console.log(`   - HOA dues imported: ${importedHOADues.length}`);
      console.log(`   - Transaction links: ${linkingResult.linkedCount}`);
      console.log(`   - Notes parsing: Complete`);
      console.log(`   - Positive amounts: Applied for income`);
      console.log(`   - Sequence linking: Operational`);
      console.log(`   - Validation: Passed`);
      console.log(`   - Ready for: Balance calculation testing`);
    } else {
      throw new Error('HOA dues import validation failed');
    }
    
    return { importedHOADues, linkingResult };
    
  } catch (error) {
    console.error(`❌ HOA dues import process failed:`, error);
    throw error;
  }
}

// Run the import
if (import.meta.url === new URL(process.argv[1], 'file://').href) {
  runHOADuesImport()
    .then(() => {
      console.log(`🎉 HOA dues import completed successfully`);
      process.exit(0);
    })
    .catch(error => {
      console.error(`💥 HOA dues import failed:`, error);
      process.exit(1);
    });
}

export { 
  runHOADuesImport, 
  importHOADuesComplete, 
  linkHOADuesToTransactions,
  validateHOADuesImport,
  parsePaymentNotes,
  generateHOADueId
};