/**
 * Configuration for Production Import Package
 * 
 * This module handles environment-specific configuration for database targeting
 */

// Environment configuration
const environments = {
  development: {
    name: 'Development',
    serviceAccountKey: './serviceAccountKey.json',
    projectId: 'sandyland-management-system',
    description: 'Local development database'
  },
  staging: {
    name: 'Staging', 
    serviceAccountKey: './serviceAccountKey-staging.json',
    projectId: 'sams-staging-6cdcd',
    description: 'Staging environment database'
  },
  production: {
    name: 'Production',
    serviceAccountKey: './sams-production-serviceAccountKey.json', 
    projectId: 'sams-sandyland-prod',
    description: 'Production database'
  },
  emulator: {
    name: 'Local Emulator',
    serviceAccountKey: './serviceAccountKey.json',
    projectId: 'demo-project',
    description: 'Firebase emulator (localhost:8080)',
    emulator: true
  }
};

/**
 * Get current environment configuration
 */
function getCurrentEnvironment() {
  // Check for explicit environment override
  const envOverride = process.env.IMPORT_ENV;
  if (envOverride && environments[envOverride]) {
    return environments[envOverride];
  }
  
  // Check for emulator
  if (process.env.FIRESTORE_EMULATOR_HOST) {
    return environments.emulator;
  }
  
  // Use NODE_ENV
  const nodeEnv = process.env.NODE_ENV;
  if (nodeEnv && environments[nodeEnv]) {
    return environments[nodeEnv];
  }
  
  // Default to development
  return environments.development;
}

/**
 * Display current configuration
 */
function displayConfiguration() {
  const env = getCurrentEnvironment();
  
  console.log(`🔧 Import Package Configuration:`);
  console.log(`   Environment: ${env.name}`);
  console.log(`   Project ID: ${env.projectId}`);
  console.log(`   Description: ${env.description}`);
  console.log(`   Service Account: ${env.serviceAccountKey}`);
  
  if (env.emulator) {
    console.log(`   Emulator Host: ${process.env.FIRESTORE_EMULATOR_HOST}`);
  }
  
  console.log(`───────────────────────────────────────────────────────`);
}

/**
 * Validate environment setup
 */
async function validateEnvironment() {
  const env = getCurrentEnvironment();
  
  try {
    // Check if service account file exists (unless using emulator)
    if (!env.emulator) {
      const fs = await import('fs');
      const path = await import('path');
      const keyPath = path.resolve(env.serviceAccountKey);
      
      if (!fs.existsSync(keyPath)) {
        throw new Error(`Service account key not found: ${keyPath}`);
      }
    }
    
    console.log(`✅ Environment validation passed: ${env.name}`);
    return true;
    
  } catch (error) {
    console.error(`❌ Environment validation failed: ${error.message}`);
    console.error(`   Make sure the service account key exists: ${env.serviceAccountKey}`);
    return false;
  }
}

/**
 * Get safety confirmation for production
 */
function requireProductionConfirmation() {
  const env = getCurrentEnvironment();
  
  if (env.name === 'Production') {
    const isDryRun = process.argv.includes('--dry-run');
    const isForced = process.argv.includes('--force');
    
    if (!isDryRun && !isForced) {
      console.error(`🚨 PRODUCTION DATABASE DETECTED`);
      console.error(`   Environment: ${env.name}`);
      console.error(`   Project: ${env.projectId}`);
      console.error(`   `);
      console.error(`   To run against production, use one of these options:`);
      console.error(`   1. Test first: node run-complete-import.js --dry-run`);
      console.error(`   2. Force run: node run-complete-import.js --force`);
      console.error(`   `);
      console.error(`   This will prevent accidental production runs.`);
      process.exit(1);
    }
    
    if (isForced && !isDryRun) {
      console.log(`⚠️  PRODUCTION IMPORT CONFIRMED WITH --force FLAG`);
      console.log(`   This will modify the production database!`);
      console.log(`   Critical user will be preserved: michael@landesman.com`);
    }
  }
}

export {
  getCurrentEnvironment,
  displayConfiguration,
  validateEnvironment, 
  requireProductionConfirmation,
  environments
};