#!/usr/bin/env node

/**
 * Transactions Import Script for Production Import
 * 
 * This script imports transactions with full automation features:
 * - Date-time-sequence document ID generation
 * - Denormalized structure (both ID and Name fields)
 * - Proper accounting signs (expenses negative, income positive)
 * - UnitId extraction from HOA dues
 * - Notes parsing and data augmentation
 * 
 * Usage: node 05-transactions-import.js
 */

import { initializeFirebase, getDb } from '../../firebase.js';
import admin from 'firebase-admin';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CLIENT_ID = 'MTC';

console.log(`🚀 Starting Transactions Import with Full Automation`);
console.log(`🏢 Client: ${CLIENT_ID}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

// Helper function to generate document ID from name (matching categories/vendors)
function generateDocId(name) {
  if (!name || typeof name !== 'string') {
    return 'unknown';
  }
  
  return name
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/--+/g, '-')
    .replace(/^-|-$/g, '');
}

// Helper function to generate transaction ID in date-time-sequence format
function generateTransactionIdFIXED(date, index) {
  const dateObj = new Date(date);
  
  if (isNaN(dateObj.getTime())) {
    console.warn(`Invalid date for transaction ID: ${date}`);
    return `invalid-date-${index}`;
  }
  
  const year = dateObj.getFullYear();
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  const day = String(dateObj.getDate()).padStart(2, '0');
  const hours = String(dateObj.getHours()).padStart(2, '0');
  const minutes = String(dateObj.getMinutes()).padStart(2, '0');
  const seconds = String(dateObj.getSeconds()).padStart(2, '0');
  const sequence = String(index).padStart(3, '0');
  
  return `${year}-${month}-${day}_${hours}${minutes}${seconds}_${sequence}`;
}

// Helper function to extract unit ID from unit field
function extractUnitId(unitField) {
  if (!unitField || typeof unitField !== 'string') {
    return null;
  }
  
  // "1A (Fletcher)" → "1A"
  const match = unitField.match(/^([A-Z0-9]+)/);
  return match ? match[1] : unitField.trim();
}

// Helper function to convert dollars to centavos
function dollarsToCentavos(amount) {
  if (typeof amount !== 'number' || isNaN(amount)) {
    console.warn(`Invalid amount for conversion: ${amount}`);
    return 0;
  }
  
  return Math.round(amount * 100);
}

// FIX 3: Remove flawed amount sign logic - preserve original transaction amounts
function preserveOriginalAmount(amount) {
  if (typeof amount !== 'number' || isNaN(amount)) {
    return 0;
  }
  
  // Preserve original sign, only convert to cents
  return Math.round(amount * 100);
}

// Helper function to determine category type
function getCategoryType(categoryName) {
  const incomeCategories = [
    'HOA Dues',
    'Account Credit',
    'Special Assessments',
    'Colonos Fee',
    'Interest Income',
    'Late Fees',
    'Penalty Fees',
    'Rental Income',
    'Service Fees'
  ];
  
  const normalized = categoryName.toLowerCase().trim();
  
  if (incomeCategories.some(income => 
    normalized.includes(income.toLowerCase())
  )) {
    return 'income';
  }
  
  return 'expense';
}

// Helper function to determine account type
function determineAccountType(accountName) {
  if (!accountName || typeof accountName !== 'string') {
    return 'bank';
  }
  
  const normalized = accountName.toLowerCase().trim();
  
  if (normalized.includes('cash') || normalized.includes('petty')) {
    return 'cash';
  }
  
  return 'bank';
}

// Helper function to map account name to account ID
function generateAccountId(accountName) {
  if (!accountName || typeof accountName !== 'string') {
    return 'unknown';
  }
  
  const normalized = accountName.toLowerCase().trim();
  
  // Map common account names to IDs
  if (normalized.includes('cibanco') || normalized.includes('ci banco')) {
    return 'cibanco';
  }
  
  if (normalized.includes('hsbc')) {
    return 'hsbc';
  }
  
  if (normalized.includes('cash') || normalized.includes('petty')) {
    return 'petty-cash';
  }
  
  // For MTC Bank, default to CiBanco
  if (normalized.includes('mtc') || normalized.includes('bank')) {
    return 'cibanco';
  }
  
  return generateDocId(accountName);
}

// Helper function to parse date
function parseDate(dateString) {
  if (!dateString) {
    return null;
  }
  
  const date = new Date(dateString);
  
  if (isNaN(date.getTime())) {
    console.warn(`Invalid date: ${dateString}`);
    return null;
  }
  
  return date;
}

async function loadTransactionsData() {
  console.log(`📖 Loading transactions data`);
  
  try {
    // Load from MTCdata directory
    const transactionsPath = join(__dirname, '../../../MTCdata/Transactions.json');
    const transactionsData = JSON.parse(readFileSync(transactionsPath, 'utf8'));
    
    console.log(`✅ Loaded ${transactionsData.length} transactions from Transactions.json`);
    
    // Sample first few transactions for validation
    console.log(`📋 Sample transactions:`);
    transactionsData.slice(0, 3).forEach((txn, index) => {
      console.log(`   ${index + 1}. ${txn.Date} - ${txn.Vendor} - $${txn.Amount} - ${txn.Category}`);
    });
    
    return transactionsData;
    
  } catch (error) {
    console.error(`❌ Error loading transactions data:`, error);
    throw error;
  }
}

async function importTransactionsComplete() {
  console.log(`💰 Starting transactions import with full automation`);
  
  try {
    const transactionsData = await loadTransactionsData();
    const db = await getDb();
    const transactionsRef = db.collection(`clients/${CLIENT_ID}/transactions`);
    
    let importedCount = 0;
    let skippedCount = 0;
    let hoaDuesCount = 0;
    const importedTransactions = [];
    
    for (let index = 0; index < transactionsData.length; index++) {
      const txnData = transactionsData[index];
      
      // Skip empty or invalid transactions
      if (!txnData.Date || !txnData.Vendor || !txnData.Category || txnData.Amount === undefined) {
        console.log(`   ⚠️  Skipping invalid transaction at index ${index}: ${JSON.stringify(txnData)}`);
        skippedCount++;
        continue;
      }
      
      try {
        // FIX 2: Add debug logging to trace date handling
        console.log(`   🔍 DEBUG - Processing transaction ${index}: Original date="${txnData.Date}"`);
        
        // Generate document ID: date-time-sequence
        const transactionId = generateTransactionIdFIXED(txnData.Date, index);
        
        // Generate IDs for denormalized fields
        const vendorId = generateDocId(txnData.Vendor);
        const categoryId = generateDocId(txnData.Category);
        const accountId = generateAccountId(txnData.Account);
        const accountType = determineAccountType(txnData.Account);
        const categoryType = getCategoryType(txnData.Category);
        
        // Extract unit ID for HOA Dues and sequence numbers from Notes
        let unitId = null;
        let sequenceNumber = null;
        let metadata = {};
        
        if (txnData.Category === 'HOA Dues' && txnData.Unit) {
          unitId = extractUnitId(txnData.Unit);
          metadata = { 
            type: 'hoa_dues',
            originalUnit: txnData.Unit,
            unitId: unitId
          };
          hoaDuesCount++;
        }
        
        // Extract sequence number from Notes field for transaction linking
        if (txnData.Notes) {
          const sequenceMatch = txnData.Notes.match(/nSeq:\s*(\d+)/);
          if (sequenceMatch) {
            sequenceNumber = parseInt(sequenceMatch[1]);
            metadata.sequenceNumber = sequenceNumber;
          }
        }
        
        // FIX 3: Preserve original amount signs - do not apply category-based conversion
        const preservedAmount = preserveOriginalAmount(txnData.Amount);
        console.log(`   🔍 DEBUG - Amount conversion: ${txnData.Amount} -> ${preservedAmount} centavos`);
        
        // FIX 2: Parse date with debug logging
        const parsedDate = parseDate(txnData.Date);
        console.log(`   🔍 DEBUG - Parsed date: ${parsedDate ? parsedDate.toISOString() : 'NULL'}`);
        
        // Build complete transaction document
        const transaction = {
          // Document ID and core fields
          id: transactionId,
          
          // Denormalized vendor fields (BOTH ID and Name)
          vendorId: vendorId,
          vendorName: txnData.Vendor,
          
          // Denormalized category fields (BOTH ID and Name)
          categoryId: categoryId,
          categoryName: txnData.Category,
          
          // Denormalized account fields (BOTH ID, Name, and Type)
          accountId: accountId,
          accountName: txnData.Account || 'MTC Bank',
          accountType: accountType,
          
          // Financial data with original signs preserved
          amount: preservedAmount, // FIX 3: Preserve original signs from source data
          currency: 'MXN',
          
          // Transaction details
          date: parsedDate, // FIX 2: Use parsed date variable for clarity
          notes: txnData.Notes || '',
          paymentMethod: 'Unknown', // Not in source data
          
          // Transaction type
          type: categoryType,
          
          // Unit ID extraction for HOA Dues
          unitId: unitId,
          
          // Sequence number for transaction linking
          sequenceNumber: sequenceNumber,
          
          // Client relationship
          clientId: CLIENT_ID,
          
          // Minimal metadata only
          metadata: {
            ...metadata,
            importIndex: index
          },
          
          // Audit fields
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          createdBy: 'production-import-setup',
          lastModified: admin.firestore.FieldValue.serverTimestamp(),
          lastModifiedBy: 'production-import-setup'
        };
        
        // FIX 2: Debug log the final transaction date before save
        console.log(`   🔍 DEBUG - Final transaction date before save: ${transaction.date ? transaction.date.toISOString() : 'NULL'}`);
        
        // FIX 2: Verify the transaction date after building
        if (transaction.date && parsedDate) {
          const timeDiff = Math.abs(transaction.date.getTime() - parsedDate.getTime());
          if (timeDiff > 1000) { // More than 1 second difference
            console.warn(`   ⚠️  WARNING - Transaction date changed during processing: ${txnData.Date} -> ${transaction.date.toISOString()}`);
          }
        }
        
        // Create transaction with explicit document ID
        await transactionsRef.doc(transactionId).set(transaction);
        
        // Store metadata separately in importMetadata collection
        const metadataRef = db.collection(`clients/${CLIENT_ID}/importMetadata`);
        await metadataRef.doc(transactionId).set({
          type: 'transaction',
          source: 'production-import-package',
          importDate: admin.firestore.FieldValue.serverTimestamp(),
          originalData: {
            date: txnData.Date,
            vendor: txnData.Vendor,
            category: txnData.Category,
            unit: txnData.Unit,
            amount: txnData.Amount,
            account: txnData.Account,
            notes: txnData.Notes
          },
          autoGenerated: true,
          importIndex: index
        });
        
        importedTransactions.push({
          id: transactionId,
          vendor: txnData.Vendor,
          category: txnData.Category,
          amount: preservedAmount, // FIX 3: Track preserved amounts
          type: categoryType,
          unitId: unitId,
          hasUnit: !!unitId
        });
        
        importedCount++;
        
        if (importedCount % 50 === 0) {
          console.log(`   📊 Imported ${importedCount} transactions...`);
        }
        
      } catch (error) {
        console.error(`   ❌ Error importing transaction at index ${index}:`, error);
        skippedCount++;
      }
    }
    
    console.log(`✅ Transactions import completed`);
    console.log(`📊 Import Summary:`);
    console.log(`   - Total processed: ${transactionsData.length}`);
    console.log(`   - Successfully imported: ${importedCount}`);
    console.log(`   - Skipped: ${skippedCount}`);
    console.log(`   - HOA Dues transactions: ${hoaDuesCount}`);
    console.log(`   - Transactions with unit IDs: ${importedTransactions.filter(t => t.hasUnit).length}`);
    
    // Summary by transaction type
    const incomeCount = importedTransactions.filter(t => t.type === 'income').length;
    const expenseCount = importedTransactions.filter(t => t.type === 'expense').length;
    
    console.log(`📋 Transaction Types:`);
    console.log(`   - Income transactions: ${incomeCount}`);
    console.log(`   - Expense transactions: ${expenseCount}`);
    
    // Summary by amount signs
    const positiveAmount = importedTransactions.filter(t => t.amount > 0).length;
    const negativeAmount = importedTransactions.filter(t => t.amount < 0).length;
    
    console.log(`💰 Amount Signs:`);
    console.log(`   - Positive amounts: ${positiveAmount}`);
    console.log(`   - Negative amounts: ${negativeAmount}`);
    
    return importedTransactions;
    
  } catch (error) {
    console.error(`❌ Transactions import failed:`, error);
    throw error;
  }
}

async function validateTransactionsImport() {
  console.log(`🔍 Validating transactions import`);
  
  try {
    const db = await getDb();
    const transactionsRef = db.collection(`clients/${CLIENT_ID}/transactions`);
    const snapshot = await transactionsRef.get();
    
    console.log(`✅ Validation: ${snapshot.size} transactions found in database`);
    
    // Check for required fields
    let validTransactions = 0;
    let invalidTransactions = 0;
    let totalAmount = 0;
    
    snapshot.forEach(doc => {
      const data = doc.data();
      
      if (data.vendorId && data.vendorName && data.categoryId && data.categoryName && 
          data.accountId && data.accountName && data.amount !== undefined && data.clientId) {
        validTransactions++;
        totalAmount += data.amount;
      } else {
        invalidTransactions++;
        console.log(`   ⚠️  Invalid transaction: ${doc.id} - missing required fields`);
      }
    });
    
    console.log(`📊 Validation Summary:`);
    console.log(`   - Valid transactions: ${validTransactions}`);
    console.log(`   - Invalid transactions: ${invalidTransactions}`);
    console.log(`   - Total balance: $${(totalAmount / 100).toFixed(2)} MXN`);
    console.log(`   - Success rate: ${validTransactions > 0 ? ((validTransactions / snapshot.size) * 100).toFixed(1) : 0}%`);
    
    return validTransactions === snapshot.size;
    
  } catch (error) {
    console.error(`❌ Transactions validation failed:`, error);
    return false;
  }
}

async function runTransactionsImport() {
  console.log(`🚀 Starting transactions import process`);
  
  try {
    // Step 1: Import transactions with full automation
    const importedTransactions = await importTransactionsComplete();
    
    // Step 2: Validate import
    const isValid = await validateTransactionsImport();
    
    if (isValid) {
      console.log(`✅ Transactions import completed successfully`);
      console.log(`📊 Final Summary:`);
      console.log(`   - Transactions imported: ${importedTransactions.length}`);
      console.log(`   - Document ID format: YYYY-MM-DD_HHMMSS_nnn`);
      console.log(`   - Denormalized structure: Complete (ID + Name fields)`);
      console.log(`   - Accounting signs: Applied (income +, expense -)`);
      console.log(`   - Unit ID extraction: Complete for HOA Dues`);
      console.log(`   - Validation: Passed`);
      console.log(`   - Ready for: HOA Dues import and linking`);
    } else {
      throw new Error('Transactions import validation failed');
    }
    
    return importedTransactions;
    
  } catch (error) {
    console.error(`❌ Transactions import process failed:`, error);
    throw error;
  }
}

// Run the import
if (import.meta.url === new URL(process.argv[1], 'file://').href) {
  runTransactionsImport()
    .then(() => {
      console.log(`🎉 Transactions import completed successfully`);
      process.exit(0);
    })
    .catch(error => {
      console.error(`💥 Transactions import failed:`, error);
      process.exit(1);
    });
}

export { 
  runTransactionsImport, 
  importTransactionsComplete, 
  validateTransactionsImport, 
  generateTransactionIdFIXED,
  extractUnitId,
  preserveOriginalAmount, // FIX 3: Export new function
  getCategoryType
};