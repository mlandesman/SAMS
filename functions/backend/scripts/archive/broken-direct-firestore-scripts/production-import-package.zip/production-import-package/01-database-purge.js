#!/usr/bin/env node

/**
 * Database Purge Script for Production Import
 * 
 * This script purges all collections to prepare for a clean import
 * while preserving the critical user: michael@landesman.com
 * 
 * Usage: node 01-database-purge.js
 */

import { initializeFirebase, getDb } from '../../firebase.js';
import admin from 'firebase-admin';

const CRITICAL_USER_EMAIL = 'michael@landesman.com';
const CLIENT_ID = 'MTC';

console.log(`🚀 Starting Database Purge for Production Import`);
console.log(`⚠️  WARNING: This will delete all data except critical user`);
console.log(`👤 Critical user to preserve: ${CRITICAL_USER_EMAIL}`);
console.log(`🏢 Client: ${CLIENT_ID}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

async function backupCriticalUser() {
  console.log(`💾 Backing up critical user: ${CRITICAL_USER_EMAIL}`);
  
  try {
    const db = await getDb();
    const usersRef = db.collection('users');
    
    // Find user by email
    const userSnapshot = await usersRef.where('email', '==', CRITICAL_USER_EMAIL).get();
    
    if (userSnapshot.empty) {
      console.log(`⚠️  Critical user ${CRITICAL_USER_EMAIL} not found in database`);
      return null;
    }
    
    const userDoc = userSnapshot.docs[0];
    const userData = userDoc.data();
    
    console.log(`✅ Found critical user: ${userDoc.id}`);
    console.log(`   - Email: ${userData.email}`);
    console.log(`   - Display Name: ${userData.displayName || 'Not set'}`);
    console.log(`   - Property Access: ${userData.propertyAccess ? Object.keys(userData.propertyAccess).join(', ') : 'None'}`);
    
    return {
      id: userDoc.id,
      data: userData
    };
    
  } catch (error) {
    console.error(`❌ Error backing up critical user:`, error);
    throw error;
  }
}

async function purgeCollection(collectionPath) {
  console.log(`🗑️  Purging collection: ${collectionPath}`);
  
  try {
    const db = await getDb();
    const collectionRef = db.collection(collectionPath);
    
    // Get all documents in batches
    let query = collectionRef.limit(500);
    let documentsDeleted = 0;
    
    while (true) {
      const snapshot = await query.get();
      
      if (snapshot.empty) {
        break;
      }
      
      // Delete documents in batch
      const batch = db.batch();
      snapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      
      await batch.commit();
      documentsDeleted += snapshot.docs.length;
      
      console.log(`   📊 Deleted ${documentsDeleted} documents from ${collectionPath}`);
      
      // Continue with next batch
      if (snapshot.docs.length < 500) {
        break;
      }
    }
    
    console.log(`✅ Collection ${collectionPath} purged: ${documentsDeleted} documents deleted`);
    return documentsDeleted;
    
  } catch (error) {
    console.error(`❌ Error purging collection ${collectionPath}:`, error);
    throw error;
  }
}

async function purgeClientSubcollections(clientId) {
  console.log(`🗑️  Purging subcollections for client: ${clientId}`);
  
  const subcollections = [
    `clients/${clientId}/transactions`,
    `clients/${clientId}/categories`,
    `clients/${clientId}/vendors`,
    // `clients/${clientId}/accounts`, // REMOVED: Using accounts array in client document only
    `clients/${clientId}/units`,
    `clients/${clientId}/paymentMethods`,
    `clients/${clientId}/hoaDues`,
    `clients/${clientId}/reports`,
    `clients/${clientId}/documents`,
    `clients/${clientId}/auditLogs`,
    `clients/${clientId}/importMetadata`
  ];
  
  let totalDeleted = 0;
  
  for (const subcollectionPath of subcollections) {
    try {
      const deleted = await purgeCollection(subcollectionPath);
      totalDeleted += deleted;
    } catch (error) {
      console.error(`❌ Failed to purge ${subcollectionPath}:`, error);
      // Continue with other collections
    }
  }
  
  console.log(`✅ Client ${clientId} subcollections purged: ${totalDeleted} total documents deleted`);
  return totalDeleted;
}

async function purgeTopLevelCollections() {
  console.log(`🗑️  Purging top-level collections`);
  
  const collections = [
    'clients', // Will be recreated with clean MTC client
    'auditLogs', // Contains wrong docIds from previous imports
    'emailConfig' // Can be recreated
    // NOTE: Preserving exchangeRates - needed for system operation
  ];
  
  let totalDeleted = 0;
  
  for (const collectionName of collections) {
    try {
      const deleted = await purgeCollection(collectionName);
      totalDeleted += deleted;
    } catch (error) {
      console.error(`❌ Failed to purge ${collectionName}:`, error);
      // Continue with other collections
    }
  }
  
  console.log(`✅ Top-level collections purged: ${totalDeleted} total documents deleted`);
  return totalDeleted;
}

async function restoreCriticalUser(userBackup) {
  if (!userBackup) {
    console.log(`⚠️  No critical user backup to restore`);
    return;
  }
  
  console.log(`🔄 Restoring critical user: ${userBackup.data.email}`);
  
  try {
    const db = await getDb();
    const usersRef = db.collection('users');
    
    // Restore user with original ID
    await usersRef.doc(userBackup.id).set({
      ...userBackup.data,
      restoredAt: admin.firestore.FieldValue.serverTimestamp(),
      restoredBy: 'production-import-purge'
    });
    
    console.log(`✅ Critical user restored: ${userBackup.id}`);
    
  } catch (error) {
    console.error(`❌ Error restoring critical user:`, error);
    throw error;
  }
}

async function createConnectionTestDoc() {
  console.log(`🔧 Creating connection test document`);
  
  try {
    const db = await getDb();
    await db.collection('connection_test').doc('connection').set({
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      purpose: 'Firestore connection verification',
      createdBy: 'production-import-purge'
    });
    
    console.log(`✅ Connection test document created`);
    
  } catch (error) {
    console.error(`❌ Error creating connection test doc:`, error);
    throw error;
  }
}

async function purgeForProduction() {
  console.log(`🚀 Starting production database purge`);
  
  try {
    // Step 1: Backup critical user
    const userBackup = await backupCriticalUser();
    
    // Step 2: Purge client subcollections first
    await purgeClientSubcollections(CLIENT_ID);
    
    // Step 3: Purge top-level collections
    await purgeTopLevelCollections();
    
    // Step 4: Restore critical user
    await restoreCriticalUser(userBackup);
    
    // Step 5: Create essential documents
    await createConnectionTestDoc();
    
    console.log(`✅ Database purged successfully - Ready for clean import`);
    console.log(`📊 Summary:`);
    console.log(`   - Critical user preserved: ${userBackup ? userBackup.data.email : 'None'}`);
    console.log(`   - Collections purged: All client and top-level collections`);
    console.log(`   - Database ready for: Production import package`);
    
  } catch (error) {
    console.error(`❌ Database purge failed:`, error);
    throw error;
  }
}

// Run the purge
if (import.meta.url === new URL(process.argv[1], 'file://').href) {
  purgeForProduction()
    .then(() => {
      console.log(`🎉 Production database purge completed successfully`);
      process.exit(0);
    })
    .catch(error => {
      console.error(`💥 Production database purge failed:`, error);
      process.exit(1);
    });
}

export { purgeForProduction };