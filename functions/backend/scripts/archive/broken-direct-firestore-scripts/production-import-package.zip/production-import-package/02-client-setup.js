#!/usr/bin/env node

/**
 * Client Setup Script for Production Import
 * 
 * This script creates the MTC client with proper structure including accounts array
 * 
 * Usage: node 02-client-setup.js
 */

import { initializeFirebase, getDb } from '../../firebase.js';
import admin from 'firebase-admin';

const CLIENT_ID = 'MTC';

console.log(`🚀 Starting MTC Client Setup for Production Import`);
console.log(`🏢 Client: ${CLIENT_ID}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

async function createMTCClientComplete() {
  console.log(`🏗️  Creating MTC client with complete structure`);
  
  try {
    const db = await getDb();
    const clientsRef = db.collection('clients');
    
    // Complete MTC client data structure
    const clientData = {
      basicInfo: {
        id: CLIENT_ID,
        fullName: 'Marina Turquesa Condominiums',
        displayName: 'MTC',
        clientType: 'HOA_Management',
        status: 'active',
        description: 'Marina Turquesa Condominiums - HOA Management & Property Services'
      },
      branding: {
        logoUrl: null,
        iconUrl: null,
        brandColors: {
          primary: '#2563eb',
          secondary: '#64748b',
          accent: '#10b981'
        }
      },
      configuration: {
        timezone: 'America/Mexico_City',
        currency: 'MXN',
        language: 'es-MX',
        dateFormat: 'DD/MM/YYYY',
        fiscalYearStart: '01/01',
        businessHours: {
          start: '09:00',
          end: '17:00',
          days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
        }
      },
      contactInfo: {
        primaryEmail: 'admin@marinaturquesa.com',
        phone: '+52 (322) 123-4567',
        address: {
          street: 'Blvd. Francisco Medina Ascencio',
          city: 'Puerto Vallarta',
          state: 'Jalisco',
          zipCode: '48333',
          country: 'Mexico'
        }
      },
      // CRITICAL: Accounts array setup for proper backend integration
      accounts: [
        {
          id: 'cibanco',
          name: 'CiBanco',
          type: 'bank',
          currency: 'MXN',
          description: 'Primary banking account',
          status: 'active',
          accountNumber: '***-***-****',
          metadata: {
            primary: true,
            category: 'operational'
          }
        },
        {
          id: 'hsbc',
          name: 'HSBC',
          type: 'bank',
          currency: 'MXN',
          description: 'Secondary banking account',
          status: 'active',
          accountNumber: '***-***-****',
          metadata: {
            primary: false,
            category: 'operational'
          }
        },
        {
          id: 'petty-cash',
          name: 'Petty Cash',
          type: 'cash',
          currency: 'MXN',
          description: 'Petty cash for small expenses',
          status: 'active',
          accountNumber: 'CASH-001',
          metadata: {
            primary: false,
            category: 'operational'
          }
        }
      ],
      // Service configuration
      services: {
        hoaManagement: {
          enabled: true,
          unitCount: 48,
          monthlyDuesAmount: 17400, // In centavos
          currency: 'MXN'
        },
        propertyManagement: {
          enabled: true,
          managedUnits: 48
        },
        financialReporting: {
          enabled: true,
          reportingPeriod: 'monthly'
        }
      },
      metadata: {
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        createdBy: 'production-import-setup',
        lastModified: admin.firestore.FieldValue.serverTimestamp(),
        lastModifiedBy: 'production-import-setup',
        version: 2,
        importGeneration: 'production-import-package',
        importDate: admin.firestore.FieldValue.serverTimestamp()
      }
    };
    
    // Create client with explicit document ID
    await clientsRef.doc(CLIENT_ID).set(clientData);
    
    console.log(`✅ MTC client created successfully`);
    console.log(`📊 Client Summary:`);
    console.log(`   - ID: ${CLIENT_ID}`);
    console.log(`   - Full Name: ${clientData.basicInfo.fullName}`);
    console.log(`   - Display Name: ${clientData.basicInfo.displayName}`);
    console.log(`   - Client Type: ${clientData.basicInfo.clientType}`);
    console.log(`   - Status: ${clientData.basicInfo.status}`);
    console.log(`   - Currency: ${clientData.configuration.currency}`);
    console.log(`   - Timezone: ${clientData.configuration.timezone}`);
    console.log(`   - Accounts: ${clientData.accounts.length} configured`);
    
    // Log accounts details
    console.log(`📋 Accounts Configuration:`);
    clientData.accounts.forEach((account, index) => {
      console.log(`   ${index + 1}. ${account.name} (${account.type})`);
      console.log(`      - ID: ${account.id}`);
      console.log(`      - Currency: ${account.currency}`);
      console.log(`      - Status: ${account.status}`);
      console.log(`      - Primary: ${account.metadata.primary ? 'Yes' : 'No'}`);
    });
    
    // Verify client creation
    const createdClient = await clientsRef.doc(CLIENT_ID).get();
    if (createdClient.exists) {
      console.log(`✅ Client verification: Document exists and is readable`);
      const data = createdClient.data();
      console.log(`   - Has basicInfo: ${!!data.basicInfo}`);
      console.log(`   - Has accounts: ${!!data.accounts} (${data.accounts?.length || 0} items)`);
      console.log(`   - Has configuration: ${!!data.configuration}`);
      console.log(`   - Has contactInfo: ${!!data.contactInfo}`);
      console.log(`   - Has metadata: ${!!data.metadata}`);
    } else {
      throw new Error('Client creation verification failed');
    }
    
    return CLIENT_ID;
    
  } catch (error) {
    console.error(`❌ Error creating MTC client:`, error);
    throw error;
  }
}

async function createDefaultAccounts() {
  console.log(`🏦 Creating default accounts in client subcollection`);
  
  try {
    const db = await getDb();
    const accountsRef = db.collection(`clients/${CLIENT_ID}/accounts`);
    
    // Account definitions matching the client accounts array
    const defaultAccounts = [
      {
        id: 'cibanco',
        name: 'CiBanco',
        type: 'bank',
        currency: 'MXN',
        description: 'Primary banking account for MTC operations',
        status: 'active',
        balance: 0, // Will be calculated from transactions
        metadata: {
          primary: true,
          category: 'operational',
          bankCode: 'CIBANCO',
          accountType: 'checking'
        }
      },
      {
        id: 'hsbc',
        name: 'HSBC',
        type: 'bank',
        currency: 'MXN',
        description: 'Secondary banking account for MTC operations',
        status: 'active',
        balance: 0,
        metadata: {
          primary: false,
          category: 'operational',
          bankCode: 'HSBC',
          accountType: 'checking'
        }
      },
      {
        id: 'petty-cash',
        name: 'Petty Cash',
        type: 'cash',
        currency: 'MXN',
        description: 'Petty cash for small expenses and immediate needs',
        status: 'active',
        balance: 0,
        metadata: {
          primary: false,
          category: 'operational',
          accountType: 'cash'
        }
      }
    ];
    
    // Create accounts using explicit document IDs
    for (const account of defaultAccounts) {
      await accountsRef.doc(account.id).set({
        ...account,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        createdBy: 'production-import-setup',
        lastModified: admin.firestore.FieldValue.serverTimestamp(),
        lastModifiedBy: 'production-import-setup'
      });
      
      console.log(`   ✅ Created account: ${account.name} (${account.id})`);
    }
    
    console.log(`✅ Default accounts created: ${defaultAccounts.length} accounts`);
    
  } catch (error) {
    console.error(`❌ Error creating default accounts:`, error);
    throw error;
  }
}

async function setupMTCClient() {
  console.log(`🚀 Starting MTC client setup`);
  
  try {
    // Step 1: Create MTC client with complete structure including accounts array
    const clientId = await createMTCClientComplete();
    
    // NOTE: Only using accounts array in client document, not subcollection
    // The backend expects accounts in the client document for proper operation
    
    console.log(`✅ MTC client setup completed successfully`);
    console.log(`📊 Setup Summary:`);
    console.log(`   - Client created: ${clientId}`);
    console.log(`   - Accounts array: 3 accounts configured in client document`);
    console.log(`   - Accounts subcollection: SKIPPED (using array only)`);
    console.log(`   - Ready for: Categories, Vendors, Units, Transactions import`);
    
  } catch (error) {
    console.error(`❌ MTC client setup failed:`, error);
    throw error;
  }
}

// Run the setup
if (import.meta.url === new URL(process.argv[1], 'file://').href) {
  setupMTCClient()
    .then(() => {
      console.log(`🎉 MTC client setup completed successfully`);
      process.exit(0);
    })
    .catch(error => {
      console.error(`💥 MTC client setup failed:`, error);
      process.exit(1);
    });
}

export { setupMTCClient, createMTCClientComplete, createDefaultAccounts };