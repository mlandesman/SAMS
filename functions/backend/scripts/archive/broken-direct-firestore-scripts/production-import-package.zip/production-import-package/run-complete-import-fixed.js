#!/usr/bin/env node

/**
 * FIXED Master Import Script for Production Import Package
 * 
 * This script fixes the issues with return value handling:
 * 1. Properly handles the object return from HOA dues import
 * 2. Checks for null values before accessing properties
 * 3. Consistent error handling across all phases
 * 
 * Usage: node run-complete-import-fixed.js [--dry-run] [--skip-purge] [--verbose]
 */

import { initializeFirebase } from '../../firebase.js';
import { purgeForProduction } from './01-database-purge.js';
import { setupMTCClient } from './02-client-setup.js';
import { importCategoriesAndVendors } from './03-categories-vendors.js';
import { runUnitsImport } from './04-units-import.js';
import { runTransactionsImport } from './05-transactions-import.js';
import { runHOADuesImport } from './06-hoa-dues-import.js';
import { 
  displayConfiguration, 
  validateEnvironment, 
  requireProductionConfirmation 
} from './config.js';

// Configuration
const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run');
const skipPurge = args.includes('--skip-purge');
const verbose = args.includes('--verbose');

// Display environment configuration
displayConfiguration();

// Validate environment setup
const isValidEnvironment = await validateEnvironment();
if (!isValidEnvironment) {
  process.exit(1);
}

// Check production safety
requireProductionConfirmation();

console.log(`🚀 Starting Complete MTC Import Package (FIXED)`);
console.log(`📋 Configuration:`);
console.log(`   - Dry run: ${isDryRun ? 'Yes' : 'No'}`);
console.log(`   - Skip purge: ${skipPurge ? 'Yes' : 'No'}`);
console.log(`   - Verbose: ${verbose ? 'Yes' : 'No'}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

// Import tracking
const importResults = {
  phases: [],
  totalDuration: 0,
  success: false,
  errors: []
};

// Helper function to log phase
function logPhase(phase, status, duration = 0, details = {}) {
  const phaseResult = {
    phase,
    status,
    duration,
    details,
    timestamp: new Date().toISOString()
  };
  
  importResults.phases.push(phaseResult);
  
  if (verbose) {
    console.log(`📊 Phase ${phase}: ${status} (${duration}ms)`);
    if (Object.keys(details).length > 0) {
      console.log(`   Details:`, details);
    }
  }
}

// Helper function to execute phase with timing
async function executePhase(phaseName, phaseFunction, skipCondition = false) {
  console.log(`\n🔄 Phase: ${phaseName}`);
  
  if (skipCondition) {
    console.log(`⏭️  Skipping ${phaseName} (user requested)`);
    logPhase(phaseName, 'skipped', 0, { reason: 'user_requested' });
    return null;
  }
  
  if (isDryRun) {
    console.log(`🔍 DRY RUN: Would execute ${phaseName}`);
    logPhase(phaseName, 'dry_run', 0, { reason: 'dry_run_mode' });
    return null;
  }
  
  const startTime = Date.now();
  
  try {
    const result = await phaseFunction();
    const duration = Date.now() - startTime;
    
    console.log(`✅ ${phaseName} completed in ${duration}ms`);
    logPhase(phaseName, 'completed', duration, { result });
    
    return result;
    
  } catch (error) {
    const duration = Date.now() - startTime;
    
    console.error(`❌ ${phaseName} failed after ${duration}ms:`, error);
    logPhase(phaseName, 'failed', duration, { error: error.message });
    
    importResults.errors.push({
      phase: phaseName,
      error: error.message,
      timestamp: new Date().toISOString()
    });
    
    throw error;
  }
}

// Main import function
async function runCompleteImport() {
  const overallStartTime = Date.now();
  
  console.log(`🚀 Starting Complete MTC Import Package Execution`);
  
  try {
    // Phase 1: Database Purge (preserving critical user)
    await executePhase(
      'Database Purge',
      purgeForProduction,
      skipPurge
    );
    
    // Phase 2: Client Setup with accounts array
    const clientResult = await executePhase(
      'Client Setup',
      setupMTCClient
    );
    
    // Phase 3: Categories and Vendors import
    const categoriesVendorsResult = await executePhase(
      'Categories & Vendors Import',
      importCategoriesAndVendors
    );
    
    // Phase 4: Units import with size integration
    const unitsResult = await executePhase(
      'Units Import',
      runUnitsImport
    );
    
    // Phase 5: Transactions import with full automation
    const transactionsResult = await executePhase(
      'Transactions Import',
      runTransactionsImport
    );
    
    // Phase 6: HOA dues import with transaction linking
    const hoaDuesResult = await executePhase(
      'HOA Dues Import',
      runHOADuesImport
    );
    
    // Calculate total duration
    importResults.totalDuration = Date.now() - overallStartTime;
    importResults.success = true;
    
    // Final summary
    console.log(`\n✅ Complete MTC Import Package Finished Successfully`);
    console.log(`📊 Final Summary:`);
    console.log(`   - Total duration: ${importResults.totalDuration}ms (${(importResults.totalDuration / 1000).toFixed(2)}s)`);
    console.log(`   - Phases completed: ${importResults.phases.filter(p => p.status === 'completed').length}`);
    console.log(`   - Phases skipped: ${importResults.phases.filter(p => p.status === 'skipped').length}`);
    console.log(`   - Phases failed: ${importResults.phases.filter(p => p.status === 'failed').length}`);
    
    if (!isDryRun) {
      // Data summary with proper null checks and correct property access
      console.log(`📈 Data Import Summary:`);
      
      // Categories and Vendors
      if (categoriesVendorsResult) {
        console.log(`   - Categories: ${categoriesVendorsResult.categories?.length || 0}`);
        console.log(`   - Vendors: ${categoriesVendorsResult.vendors?.length || 0}`);
      } else {
        console.log(`   - Categories: Not imported (null result)`);
        console.log(`   - Vendors: Not imported (null result)`);
      }
      
      // Units - returns array directly
      if (unitsResult && Array.isArray(unitsResult)) {
        console.log(`   - Units: ${unitsResult.length}`);
      } else {
        console.log(`   - Units: Not imported (null or invalid result)`);
      }
      
      // Transactions - returns array directly
      if (transactionsResult && Array.isArray(transactionsResult)) {
        console.log(`   - Transactions: ${transactionsResult.length}`);
      } else {
        console.log(`   - Transactions: Not imported (null or invalid result)`);
      }
      
      // HOA Dues - returns object { importedHOADues, linkingResult }
      if (hoaDuesResult && typeof hoaDuesResult === 'object') {
        console.log(`   - HOA Dues: ${hoaDuesResult.importedHOADues?.length || 0}`);
        console.log(`   - Transaction Links: ${hoaDuesResult.linkingResult?.linkedCount || 0}`);
      } else {
        console.log(`   - HOA Dues: Not imported (null or invalid result)`);
      }
    } else {
      console.log(`\n📋 DRY RUN - No data was actually imported`);
    }
    
    console.log(`\n🎯 Next Steps:`);
    console.log(`   1. Verify data integrity in database`);
    console.log(`   2. Run balance calculation tests`);
    console.log(`   3. Test transaction display with red/green coloring`);
    console.log(`   4. Verify HOA dues income classification`);
    console.log(`   5. Test all frontend functionality`);
    console.log(`   6. Ready for production deployment when code refactor complete`);
    
    return importResults;
    
  } catch (error) {
    importResults.totalDuration = Date.now() - overallStartTime;
    importResults.success = false;
    
    console.error(`\n❌ Complete MTC Import Package Failed:`);
    console.error(`   Error: ${error.message}`);
    console.error(`   Duration: ${importResults.totalDuration}ms`);
    console.error(`   Phases completed before failure: ${importResults.phases.filter(p => p.status === 'completed').length}`);
    
    if (importResults.errors.length > 0) {
      console.error(`\n🔍 Error Details:`);
      importResults.errors.forEach((err, index) => {
        console.error(`   ${index + 1}. ${err.phase}: ${err.error}`);
      });
    }
    
    throw error;
  }
}

// Validation function
async function validateImportResults() {
  console.log(`🔍 Validating import results...`);
  
  if (isDryRun) {
    console.log(`⏭️  Skipping validation (dry run mode)`);
    return true;
  }
  
  try {
    const { getDb } = await import('../../firebase.js');
    const db = await getDb();
    const CLIENT_ID = 'MTC';
    
    // Check each collection
    const collections = [
      'clients',
      `clients/${CLIENT_ID}/categories`,
      `clients/${CLIENT_ID}/vendors`,
      `clients/${CLIENT_ID}/units`,
      `clients/${CLIENT_ID}/transactions`,
      `clients/${CLIENT_ID}/hoaDues`
    ];
    
    const counts = {};
    
    for (const collectionPath of collections) {
      const snapshot = await db.collection(collectionPath).get();
      counts[collectionPath] = snapshot.size;
    }
    
    console.log(`📊 Collection Counts:`);
    Object.entries(counts).forEach(([path, count]) => {
      console.log(`   - ${path}: ${count} documents`);
    });
    
    // Basic validation
    const hasClient = counts['clients'] > 0;
    const hasCategories = counts[`clients/${CLIENT_ID}/categories`] > 0;
    const hasVendors = counts[`clients/${CLIENT_ID}/vendors`] > 0;
    const hasUnits = counts[`clients/${CLIENT_ID}/units`] > 0;
    const hasTransactions = counts[`clients/${CLIENT_ID}/transactions`] > 0;
    const hasHOADues = counts[`clients/${CLIENT_ID}/hoaDues`] > 0;
    
    const isValid = hasClient && hasCategories && hasVendors && hasUnits && hasTransactions && hasHOADues;
    
    if (isValid) {
      console.log(`✅ Import validation passed`);
    } else {
      console.error(`❌ Import validation failed`);
      console.error(`   - Client: ${hasClient ? 'OK' : 'MISSING'}`);
      console.error(`   - Categories: ${hasCategories ? 'OK' : 'MISSING'}`);
      console.error(`   - Vendors: ${hasVendors ? 'OK' : 'MISSING'}`);
      console.error(`   - Units: ${hasUnits ? 'OK' : 'MISSING'}`);
      console.error(`   - Transactions: ${hasTransactions ? 'OK' : 'MISSING'}`);
      console.error(`   - HOA Dues: ${hasHOADues ? 'OK' : 'MISSING'}`);
    }
    
    return isValid;
    
  } catch (error) {
    console.error(`❌ Validation failed:`, error);
    return false;
  }
}

// Run the complete import
if (import.meta.url === `file://${process.argv[1]}`) {
  runCompleteImport()
    .then(async (results) => {
      console.log(`\n🎉 Complete MTC Import Package completed successfully!`);
      
      // Run validation
      const validationResult = await validateImportResults();
      
      if (validationResult) {
        console.log(`✅ All systems ready for production deployment`);
        process.exit(0);
      } else {
        console.error(`❌ Validation failed - manual review required`);
        process.exit(1);
      }
    })
    .catch(error => {
      console.error(`\n💥 Complete MTC Import Package failed:`, error);
      process.exit(1);
    });
}

export { runCompleteImport, validateImportResults };