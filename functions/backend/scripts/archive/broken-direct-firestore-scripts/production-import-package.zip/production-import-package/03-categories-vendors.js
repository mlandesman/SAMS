#!/usr/bin/env node

/**
 * Categories and Vendors Import Script for Production Import
 * 
 * This script imports categories and vendors with correct document IDs
 * - Categories: Direct name as docId (NO "cat-" prefix)
 * - Vendors: Direct name as docId (NO "ven-" prefix)
 * 
 * Usage: node 03-categories-vendors.js
 */

import { initializeFirebase, getDb } from '../../firebase.js';
import admin from 'firebase-admin';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CLIENT_ID = 'MTC';

console.log(`🚀 Starting Categories and Vendors Import`);
console.log(`🏢 Client: ${CLIENT_ID}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

// Helper function to generate document ID from name (NO prefixes)
function generateDocId(name) {
  if (!name || typeof name !== 'string') {
    throw new Error(`Invalid name for document ID: ${name}`);
  }
  
  return name
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')           // Replace spaces with hyphens
    .replace(/[^a-z0-9-]/g, '')     // Remove non-alphanumeric except hyphens
    .replace(/--+/g, '-')           // Replace multiple hyphens with single
    .replace(/^-|-$/g, '');         // Remove leading/trailing hyphens
}

// Helper function to determine category type (income vs expense)
function determineCategoryType(categoryName) {
  const incomeCategories = [
    'HOA Dues',
    'Account Credit',
    'Special Assessments',
    'Colonos Fee',
    'Interest Income',
    'Late Fees',
    'Penalty Fees',
    'Rental Income',
    'Service Fees'
  ];
  
  const normalized = categoryName.toLowerCase().trim();
  
  // Check for explicit income categories
  if (incomeCategories.some(income => 
    normalized.includes(income.toLowerCase())
  )) {
    return 'income';
  }
  
  // Check for keywords that indicate income
  const incomeKeywords = ['dues', 'fee', 'income', 'credit', 'assessment'];
  if (incomeKeywords.some(keyword => normalized.includes(keyword))) {
    return 'income';
  }
  
  // Default to expense
  return 'expense';
}

// Helper function to determine vendor type
function determineVendorType(vendorName) {
  const serviceProviders = [
    'CFE', 'CiBanco', 'HSBC', 'Telmex', 'Aquas del Caribe',
    'Acuatica Gamez', 'Amazon Business'
  ];
  
  const normalized = vendorName.toLowerCase().trim();
  
  // Check for service providers
  if (serviceProviders.some(provider => 
    normalized.includes(provider.toLowerCase())
  )) {
    return 'service_provider';
  }
  
  // Check for keywords that indicate service type
  if (normalized.includes('maintenance') || normalized.includes('repair')) {
    return 'maintenance';
  }
  
  if (normalized.includes('supply') || normalized.includes('material')) {
    return 'supplier';
  }
  
  // Default to general vendor
  return 'vendor';
}

async function loadCategoriesData() {
  console.log(`📖 Loading categories data`);
  
  try {
    // Load from MTCdata directory
    const categoriesPath = join(__dirname, '../../../MTCdata/Categories.json');
    const categoriesData = JSON.parse(readFileSync(categoriesPath, 'utf8'));
    
    console.log(`✅ Loaded ${categoriesData.length} categories from Categories.json`);
    
    // Sample first few categories for validation
    console.log(`📋 Sample categories:`);
    categoriesData.slice(0, 5).forEach((item, index) => {
      console.log(`   ${index + 1}. ${item.Categories}`);
    });
    
    return categoriesData;
    
  } catch (error) {
    console.error(`❌ Error loading categories data:`, error);
    throw error;
  }
}

async function loadVendorsData() {
  console.log(`📖 Loading vendors data`);
  
  try {
    // Load from MTCdata directory
    const vendorsPath = join(__dirname, '../../../MTCdata/Vendors.json');
    const vendorsData = JSON.parse(readFileSync(vendorsPath, 'utf8'));
    
    console.log(`✅ Loaded ${vendorsData.length} vendors from Vendors.json`);
    
    // Sample first few vendors for validation
    console.log(`📋 Sample vendors:`);
    vendorsData.slice(0, 5).forEach((item, index) => {
      console.log(`   ${index + 1}. ${item.Vendors}`);
    });
    
    return vendorsData;
    
  } catch (error) {
    console.error(`❌ Error loading vendors data:`, error);
    throw error;
  }
}

async function importCategories() {
  console.log(`📂 Starting categories import`);
  
  try {
    const categoriesData = await loadCategoriesData();
    const db = await getDb();
    const categoriesRef = db.collection(`clients/${CLIENT_ID}/categories`);
    
    let importedCount = 0;
    let skippedCount = 0;
    const importedCategories = [];
    
    for (const item of categoriesData) {
      const categoryName = item.Categories;
      
      if (!categoryName || typeof categoryName !== 'string') {
        console.log(`   ⚠️  Skipping invalid category: ${JSON.stringify(item)}`);
        skippedCount++;
        continue;
      }
      
      try {
        // Generate document ID using direct name (NO "cat-" prefix)
        const docId = generateDocId(categoryName);
        const categoryType = determineCategoryType(categoryName);
        
        // Build category document
        const categoryDoc = {
          // Use both categoryId and categoryName for denormalized structure
          categoryId: docId,
          categoryName: categoryName,
          name: categoryName, // Legacy field compatibility
          type: categoryType,
          description: `${categoryType === 'income' ? 'Income' : 'Expense'} category: ${categoryName}`,
          status: 'active',
          clientId: CLIENT_ID,
          metadata: {
            autoGenerated: true
          },
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          createdBy: 'production-import-setup',
          lastModified: admin.firestore.FieldValue.serverTimestamp(),
          lastModifiedBy: 'production-import-setup'
        };
        
        // Create category with explicit document ID
        await categoriesRef.doc(docId).set(categoryDoc);
        
        // Store metadata separately in importMetadata collection
        const metadataRef = db.collection(`clients/${CLIENT_ID}/importMetadata`);
        await metadataRef.doc(`category-${docId}`).set({
          type: 'category',
          source: 'production-import-package',
          importDate: admin.firestore.FieldValue.serverTimestamp(),
          originalData: {
            name: categoryName
          },
          autoGenerated: true
        });
        
        importedCategories.push({
          docId,
          name: categoryName,
          type: categoryType
        });
        
        importedCount++;
        
        if (importedCount % 10 === 0) {
          console.log(`   📊 Imported ${importedCount} categories...`);
        }
        
      } catch (error) {
        console.error(`   ❌ Error importing category "${categoryName}":`, error);
        skippedCount++;
      }
    }
    
    console.log(`✅ Categories import completed`);
    console.log(`📊 Import Summary:`);
    console.log(`   - Total processed: ${categoriesData.length}`);
    console.log(`   - Successfully imported: ${importedCount}`);
    console.log(`   - Skipped: ${skippedCount}`);
    console.log(`   - Income categories: ${importedCategories.filter(cat => cat.type === 'income').length}`);
    console.log(`   - Expense categories: ${importedCategories.filter(cat => cat.type === 'expense').length}`);
    
    return importedCategories;
    
  } catch (error) {
    console.error(`❌ Categories import failed:`, error);
    throw error;
  }
}

async function importVendors() {
  console.log(`🏪 Starting vendors import`);
  
  try {
    const vendorsData = await loadVendorsData();
    const db = await getDb();
    const vendorsRef = db.collection(`clients/${CLIENT_ID}/vendors`);
    
    let importedCount = 0;
    let skippedCount = 0;
    const importedVendors = [];
    
    for (const item of vendorsData) {
      const vendorName = item.Vendors;
      
      if (!vendorName || typeof vendorName !== 'string') {
        console.log(`   ⚠️  Skipping invalid vendor: ${JSON.stringify(item)}`);
        skippedCount++;
        continue;
      }
      
      try {
        // Generate document ID using direct name (NO "ven-" prefix)
        const docId = generateDocId(vendorName);
        const vendorType = determineVendorType(vendorName);
        
        // Build vendor document
        const vendorDoc = {
          // Use both vendorId and vendorName for denormalized structure
          vendorId: docId,
          vendorName: vendorName,
          name: vendorName, // Legacy field compatibility
          type: vendorType,
          description: `${vendorType.replace('_', ' ')} vendor: ${vendorName}`,
          status: 'active',
          clientId: CLIENT_ID,
          contactInfo: {
            email: null,
            phone: null,
            address: null
          },
          metadata: {
            autoGenerated: true,
            vendorType: vendorType
          },
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          createdBy: 'production-import-setup',
          lastModified: admin.firestore.FieldValue.serverTimestamp(),
          lastModifiedBy: 'production-import-setup'
        };
        
        // Create vendor with explicit document ID
        await vendorsRef.doc(docId).set(vendorDoc);
        
        // Store metadata separately in importMetadata collection
        const metadataRef = db.collection(`clients/${CLIENT_ID}/importMetadata`);
        await metadataRef.doc(`vendor-${docId}`).set({
          type: 'vendor',
          source: 'production-import-package',
          importDate: admin.firestore.FieldValue.serverTimestamp(),
          originalData: {
            name: vendorName
          },
          autoGenerated: true,
          vendorType: vendorType
        });
        
        importedVendors.push({
          docId,
          name: vendorName,
          type: vendorType
        });
        
        importedCount++;
        
        if (importedCount % 10 === 0) {
          console.log(`   📊 Imported ${importedCount} vendors...`);
        }
        
      } catch (error) {
        console.error(`   ❌ Error importing vendor "${vendorName}":`, error);
        skippedCount++;
      }
    }
    
    console.log(`✅ Vendors import completed`);
    console.log(`📊 Import Summary:`);
    console.log(`   - Total processed: ${vendorsData.length}`);
    console.log(`   - Successfully imported: ${importedCount}`);
    console.log(`   - Skipped: ${skippedCount}`);
    console.log(`   - Service providers: ${importedVendors.filter(v => v.type === 'service_provider').length}`);
    console.log(`   - General vendors: ${importedVendors.filter(v => v.type === 'vendor').length}`);
    console.log(`   - Maintenance: ${importedVendors.filter(v => v.type === 'maintenance').length}`);
    
    return importedVendors;
    
  } catch (error) {
    console.error(`❌ Vendors import failed:`, error);
    throw error;
  }
}

async function importCategoriesAndVendors() {
  console.log(`🚀 Starting categories and vendors import`);
  
  try {
    // Step 1: Import categories
    const categories = await importCategories();
    
    // Step 2: Import vendors
    const vendors = await importVendors();
    
    console.log(`✅ Categories and vendors import completed successfully`);
    console.log(`📊 Final Summary:`);
    console.log(`   - Categories imported: ${categories.length}`);
    console.log(`   - Vendors imported: ${vendors.length}`);
    console.log(`   - Total documents created: ${categories.length + vendors.length}`);
    console.log(`   - Document ID format: Direct name (no prefixes)`);
    console.log(`   - Ready for: Units and Transactions import`);
    
    return { categories, vendors };
    
  } catch (error) {
    console.error(`❌ Categories and vendors import failed:`, error);
    throw error;
  }
}

// Run the import
if (import.meta.url === new URL(process.argv[1], 'file://').href) {
  importCategoriesAndVendors()
    .then(() => {
      console.log(`🎉 Categories and vendors import completed successfully`);
      process.exit(0);
    })
    .catch(error => {
      console.error(`💥 Categories and vendors import failed:`, error);
      process.exit(1);
    });
}

export { 
  importCategoriesAndVendors, 
  importCategories, 
  importVendors, 
  generateDocId, 
  determineCategoryType, 
  determineVendorType 
};