# Environment Configuration Guide

This guide explains how to run the import package against different databases and environments.

## Quick Reference

| Environment | Command | Database |
|-------------|---------|----------|
| **Development** | `node run-complete-import.js --dry-run` | Dev Firebase project |
| **Staging** | `NODE_ENV=staging node run-complete-import.js --dry-run` | Staging Firebase project |
| **Production** | `NODE_ENV=production node run-complete-import.js --dry-run --force` | Production Firebase project |
| **Local Emulator** | `FIRESTORE_EMULATOR_HOST=localhost:8080 node run-complete-import.js --dry-run` | Firebase emulator |

## Environment Details

### 1. Development Database (Default)

**Use Case**: Local development and testing  
**Database**: `sandyland-management-system` (dev project)  
**Service Account**: `serviceAccountKey.json`

```bash
cd backend/scripts/production-import-package

# Test run (recommended first)
node run-complete-import.js --dry-run

# Actual import
node run-complete-import.js
```

### 2. Staging Database

**Use Case**: Pre-production testing  
**Database**: `sams-staging-6cdcd`  
**Service Account**: `serviceAccountKey-staging.json`

```bash
cd backend/scripts/production-import-package

# Test run
NODE_ENV=staging node run-complete-import.js --dry-run

# Actual import
NODE_ENV=staging node run-complete-import.js
```

### 3. Production Database

**Use Case**: Live production data  
**Database**: `sams-sandyland-prod`  
**Service Account**: `sams-production-serviceAccountKey.json`

```bash
cd backend/scripts/production-import-package

# Test run (ALWAYS do this first)
NODE_ENV=production node run-complete-import.js --dry-run

# Actual import (requires --force flag for safety)
NODE_ENV=production node run-complete-import.js --force
```

**⚠️ Production Safety Features:**
- Requires `--force` flag to prevent accidental runs
- Always preserves critical user (`michael@landesman.com`)
- Creates backup before any purge operations
- Comprehensive validation before execution

### 4. Firebase Emulator (Local)

**Use Case**: Local testing without affecting real databases  
**Database**: Local Firebase emulator  
**Setup**: Must start emulator first

```bash
# Terminal 1: Start Firebase emulator
firebase emulators:start --only firestore

# Terminal 2: Run import against emulator
cd backend/scripts/production-import-package
FIRESTORE_EMULATOR_HOST=localhost:8080 node run-complete-import.js --dry-run
```

## Advanced Environment Configuration

### Custom Environment Override

You can override the environment detection using `IMPORT_ENV`:

```bash
# Force development environment
IMPORT_ENV=development node run-complete-import.js --dry-run

# Force staging environment  
IMPORT_ENV=staging node run-complete-import.js --dry-run

# Force emulator environment
IMPORT_ENV=emulator node run-complete-import.js --dry-run
```

### Backend Server Integration

**Important**: The import scripts connect **directly to Firestore**, not through your backend server (localhost:5001). This means:

- ✅ Scripts work regardless of backend server status
- ✅ Bypasses API rate limits and validation (intentional for bulk import)
- ✅ Faster import process
- ⚠️ Must ensure field schema compliance manually

If you want to test with backend validation:
1. Start your backend server: `npm run dev` (localhost:5001)
2. Run import scripts (they'll still connect directly to Firestore)
3. Use frontend or API calls to verify data integrity

## Environment Validation

The import package automatically validates your environment setup:

```bash
# Check environment configuration
node -e "import('./config.js').then(c => c.displayConfiguration())"
```

**Validation checks:**
- ✅ Service account key file exists
- ✅ Correct project ID loaded
- ✅ Environment variables properly set
- ✅ Emulator host configured (if using emulator)

## Troubleshooting

### Common Issues

#### 1. Service Account Key Not Found
```
❌ Environment validation failed: Service account key not found: ./serviceAccountKey.json
```

**Solution**: Ensure you have the correct service account key files:
- `serviceAccountKey.json` (development)
- `serviceAccountKey-staging.json` (staging)  
- `sams-production-serviceAccountKey.json` (production)

#### 2. Wrong Project Selected
```
🔑 Using Firebase project: wrong-project-id
```

**Solution**: Check your `NODE_ENV` or use `IMPORT_ENV` override:
```bash
IMPORT_ENV=development node run-complete-import.js --dry-run
```

#### 3. Production Safety Block
```
🚨 PRODUCTION DATABASE DETECTED
To run against production, use one of these options:
1. Test first: node run-complete-import.js --dry-run
2. Force run: node run-complete-import.js --force
```

**Solution**: This is intentional safety. Use `--force` flag for production:
```bash
NODE_ENV=production node run-complete-import.js --force
```

#### 4. Emulator Not Running
```
Error: connect ECONNREFUSED 127.0.0.1:8080
```

**Solution**: Start the Firebase emulator first:
```bash
firebase emulators:start --only firestore
```

## Best Practices

### 1. Always Test First
```bash
# ALWAYS run dry-run first in any environment
node run-complete-import.js --dry-run
```

### 2. Development Workflow
```bash
# 1. Test locally
node run-complete-import.js --dry-run

# 2. Test in staging
NODE_ENV=staging node run-complete-import.js --dry-run

# 3. Deploy to production
NODE_ENV=production node run-complete-import.js --dry-run
NODE_ENV=production node run-complete-import.js --force
```

### 3. Backup Strategy
- Development: No backup needed (test data)
- Staging: Optional backup
- Production: **MANDATORY** backup (automatic in script)

### 4. Verification Steps
After any import:
1. Check database collections for expected data
2. Verify balance calculations (~$184K MXN)
3. Test frontend functionality
4. Confirm HOA dues linking

## Environment Summary

| Environment | Risk Level | Backup | Force Required | Use Case |
|-------------|------------|--------|----------------|----------|
| Development | Low | No | No | Daily development |
| Staging | Medium | Optional | No | Pre-production testing |
| Production | High | Yes (auto) | Yes | Live deployment |
| Emulator | None | No | No | Isolated testing |

Choose the appropriate environment based on your testing needs and risk tolerance.