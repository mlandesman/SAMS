#!/usr/bin/env node

/**
 * Units Import Script for Production Import
 * 
 * This script imports units with UnitSizes integration
 * - Combines Units.json + UnitSizes.json data
 * - Uses UnitID as document ID directly
 * - Includes owner information, dues, and size data
 * 
 * Usage: node 04-units-import.js
 */

import { initializeFirebase, getDb } from '../../firebase.js';
import admin from 'firebase-admin';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const CLIENT_ID = 'MTC';

console.log(`🚀 Starting Units Import with UnitSizes Integration`);
console.log(`🏢 Client: ${CLIENT_ID}`);
console.log(`⏰ Started at: ${new Date().toISOString()}`);
console.log(`─────────────────────────────────────────────────────────`);

// Helper function to convert dues to centavos
function dollarsToCentavos(amount) {
  if (typeof amount !== 'number' || isNaN(amount)) {
    console.warn(`Invalid amount for conversion: ${amount}`);
    return 0;
  }
  
  return Math.round(amount * 100);
}

// Helper function to determine unit type based on size
function determineUnitType(sizeData) {
  if (!sizeData || !sizeData.sqft) {
    return 'standard';
  }
  
  const sqft = sizeData.sqft;
  
  if (sqft > 2000) {
    return 'penthouse';
  } else if (sqft > 1500) {
    return 'large';
  } else if (sqft > 1000) {
    return 'standard';
  } else {
    return 'small';
  }
}

// Helper function to validate email format
function validateEmail(email) {
  if (!email || typeof email !== 'string') {
    return false;
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

// Helper function to clean owner name
function cleanOwnerName(name) {
  if (!name || typeof name !== 'string') {
    return null;
  }
  
  return name.trim().replace(/\s+/g, ' ');
}

async function loadUnitsData() {
  console.log(`📖 Loading units data`);
  
  try {
    // Load from MTCdata directory
    const unitsPath = join(__dirname, '../../../MTCdata/Units.json');
    const unitsData = JSON.parse(readFileSync(unitsPath, 'utf8'));
    
    console.log(`✅ Loaded ${unitsData.length} units from Units.json`);
    
    // Sample first few units for validation
    console.log(`📋 Sample units:`);
    unitsData.slice(0, 3).forEach((unit, index) => {
      console.log(`   ${index + 1}. ${unit.UnitID} - ${unit.Owner} - $${unit.Dues}`);
    });
    
    return unitsData;
    
  } catch (error) {
    console.error(`❌ Error loading units data:`, error);
    throw error;
  }
}

async function loadUnitSizesData() {
  console.log(`📖 Loading unit sizes data`);
  
  try {
    // Load from MTCdata directory
    const unitSizesPath = join(__dirname, '../../../MTCdata/UnitSizes.json');
    const unitSizesData = JSON.parse(readFileSync(unitSizesPath, 'utf8'));
    
    console.log(`✅ Loaded ${unitSizesData.length} unit sizes from UnitSizes.json`);
    
    // Sample first few unit sizes for validation
    console.log(`📋 Sample unit sizes:`);
    unitSizesData.slice(0, 3).forEach((size, index) => {
      console.log(`   ${index + 1}. ${size.Condo} - ${size['m² ']} m² - ${size['ft² ']} ft²`);
    });
    
    return unitSizesData;
    
  } catch (error) {
    console.error(`❌ Error loading unit sizes data:`, error);
    throw error;
  }
}

async function importUnitsComplete() {
  console.log(`🏠 Starting units import with size integration`);
  
  try {
    // Load both data sources
    const unitsData = await loadUnitsData();
    const unitSizesData = await loadUnitSizesData();
    
    // Create size lookup by unit ID
    const sizeLookup = {};
    unitSizesData.forEach(size => {
      sizeLookup[size.Condo] = {
        sqMeters: size['m² '],
        sqft: size['ft² '],
        percentage: size['%']
      };
    });
    
    console.log(`📊 Created size lookup for ${Object.keys(sizeLookup).length} units`);
    
    const db = await getDb();
    const unitsRef = db.collection(`clients/${CLIENT_ID}/units`);
    
    let importedCount = 0;
    let skippedCount = 0;
    let missingSize = 0;
    const importedUnits = [];
    
    for (const unit of unitsData) {
      const unitId = unit.UnitID;
      
      if (!unitId || typeof unitId !== 'string') {
        console.log(`   ⚠️  Skipping unit with invalid ID: ${JSON.stringify(unit)}`);
        skippedCount++;
        continue;
      }
      
      try {
        // Get size data for this unit
        const sizeData = sizeLookup[unitId];
        
        if (!sizeData) {
          console.log(`   ⚠️  No size data found for unit ${unitId}`);
          missingSize++;
        }
        
        // Clean and validate owner data
        const ownerName = cleanOwnerName(unit.Owner);
        const ownerEmail = validateEmail(unit.eMail) ? unit.eMail.trim() : null;
        
        // Convert dues to centavos
        const duesAmount = dollarsToCentavos(unit.Dues);
        
        // Determine unit type
        const unitType = determineUnitType(sizeData);
        
        // Build complete unit document
        const unitDoc = {
          // Use unitId as both document ID and field
          unitId: unitId,
          unit: unitId, // Legacy field compatibility
          
          // Owner information
          owner: {
            name: ownerName,
            email: ownerEmail,
            percentage: unit['% Owner'] || 0
          },
          
          // Financial information
          dues: {
            amount: duesAmount, // In centavos
            currency: 'MXN',
            percentage: unit['% Owner'] || 0
          },
          
          // Size information (if available)
          size: sizeData ? {
            sqMeters: sizeData.sqMeters,
            sqft: sizeData.sqft,
            percentage: sizeData.percentage
          } : null,
          
          // Unit classification
          type: unitType,
          status: 'active',
          
          // Client relationship
          clientId: CLIENT_ID,
          
          // Metadata
          metadata: {
            hasSizeData: !!sizeData,
            autoGenerated: true
          },
          
          // Audit fields
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          createdBy: 'production-import-setup',
          lastModified: admin.firestore.FieldValue.serverTimestamp(),
          lastModifiedBy: 'production-import-setup'
        };
        
        // Create unit with explicit document ID (UnitID)
        await unitsRef.doc(unitId).set(unitDoc);
        
        // Store metadata separately in importMetadata collection
        const metadataRef = db.collection(`clients/${CLIENT_ID}/importMetadata`);
        await metadataRef.doc(`unit-${unitId}`).set({
          type: 'unit',
          source: 'production-import-package',
          importDate: admin.firestore.FieldValue.serverTimestamp(),
          originalData: {
            unitId: unit.UnitID,
            owner: unit.Owner,
            email: unit.eMail,
            dues: unit.Dues,
            ownerPercentage: unit['% Owner']
          },
          hasSizeData: !!sizeData,
          autoGenerated: true
        });
        
        importedUnits.push({
          unitId,
          owner: ownerName,
          email: ownerEmail,
          dues: duesAmount,
          type: unitType,
          hasSize: !!sizeData
        });
        
        importedCount++;
        
        if (importedCount % 10 === 0) {
          console.log(`   📊 Imported ${importedCount} units...`);
        }
        
      } catch (error) {
        console.error(`   ❌ Error importing unit "${unitId}":`, error);
        skippedCount++;
      }
    }
    
    console.log(`✅ Units import completed`);
    console.log(`📊 Import Summary:`);
    console.log(`   - Total processed: ${unitsData.length}`);
    console.log(`   - Successfully imported: ${importedCount}`);
    console.log(`   - Skipped: ${skippedCount}`);
    console.log(`   - Missing size data: ${missingSize}`);
    console.log(`   - Units with size data: ${importedCount - missingSize}`);
    
    // Summary by unit type
    const typeCount = {};
    importedUnits.forEach(unit => {
      typeCount[unit.type] = (typeCount[unit.type] || 0) + 1;
    });
    
    console.log(`📋 Unit Types:`);
    Object.entries(typeCount).forEach(([type, count]) => {
      console.log(`   - ${type}: ${count} units`);
    });
    
    // Summary by email availability
    const unitsWithEmail = importedUnits.filter(unit => unit.email).length;
    const unitsWithoutEmail = importedCount - unitsWithEmail;
    
    console.log(`📧 Email Data:`);
    console.log(`   - Units with email: ${unitsWithEmail}`);
    console.log(`   - Units without email: ${unitsWithoutEmail}`);
    
    return importedUnits;
    
  } catch (error) {
    console.error(`❌ Units import failed:`, error);
    throw error;
  }
}

async function validateUnitsImport() {
  console.log(`🔍 Validating units import`);
  
  try {
    const db = await getDb();
    const unitsRef = db.collection(`clients/${CLIENT_ID}/units`);
    const snapshot = await unitsRef.get();
    
    console.log(`✅ Validation: ${snapshot.size} units found in database`);
    
    // Check for required fields
    let validUnits = 0;
    let invalidUnits = 0;
    
    snapshot.forEach(doc => {
      const data = doc.data();
      
      if (data.unitId && data.owner && data.dues && data.clientId) {
        validUnits++;
      } else {
        invalidUnits++;
        console.log(`   ⚠️  Invalid unit: ${doc.id} - missing required fields`);
      }
    });
    
    console.log(`📊 Validation Summary:`);
    console.log(`   - Valid units: ${validUnits}`);
    console.log(`   - Invalid units: ${invalidUnits}`);
    console.log(`   - Success rate: ${validUnits > 0 ? ((validUnits / snapshot.size) * 100).toFixed(1) : 0}%`);
    
    return validUnits === snapshot.size;
    
  } catch (error) {
    console.error(`❌ Units validation failed:`, error);
    return false;
  }
}

async function runUnitsImport() {
  console.log(`🚀 Starting units import process`);
  
  try {
    // Step 1: Import units with size integration
    const importedUnits = await importUnitsComplete();
    
    // Step 2: Validate import
    const isValid = await validateUnitsImport();
    
    if (isValid) {
      console.log(`✅ Units import completed successfully`);
      console.log(`📊 Final Summary:`);
      console.log(`   - Units imported: ${importedUnits.length}`);
      console.log(`   - Size data integration: Complete`);
      console.log(`   - Document ID format: UnitID directly`);
      console.log(`   - Validation: Passed`);
      console.log(`   - Ready for: Transactions import`);
    } else {
      throw new Error('Units import validation failed');
    }
    
    return importedUnits;
    
  } catch (error) {
    console.error(`❌ Units import process failed:`, error);
    throw error;
  }
}

// Run the import
if (import.meta.url === new URL(process.argv[1], 'file://').href) {
  runUnitsImport()
    .then(() => {
      console.log(`🎉 Units import completed successfully`);
      process.exit(0);
    })
    .catch(error => {
      console.error(`💥 Units import failed:`, error);
      process.exit(1);
    });
}

export { 
  runUnitsImport, 
  importUnitsComplete, 
  validateUnitsImport, 
  loadUnitsData, 
  loadUnitSizesData 
};