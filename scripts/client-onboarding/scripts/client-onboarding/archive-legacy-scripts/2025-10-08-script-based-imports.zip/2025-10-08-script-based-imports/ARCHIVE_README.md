# Legacy Script-Based Import System - Archived

**Archive Date:** October 8, 2025  
**Reason:** Migrated to UI-based import system  
**Archived By:** System cleanup

## What Was Archived

This directory contains the legacy **command-line script-based import and purge system** that has been replaced by the **UI-based import system** accessible through the SAMS web interface.

### Why These Were Archived

1. **UI-Based System is Now Primary**: All import/purge operations are now done through the web UI at `/settings/import-management`
2. **Different File Formats**: 
   - Legacy scripts used `client-config.json` (lowercase, hyphenated)
   - UI system uses `Client.json` (capital C, no hyphen)
3. **Maintenance Confusion**: Having both systems caused confusion about which files and methods to use

## Archived Files

### Shell Scripts (3 files)
- `run-complete-import.sh` - Main command-line import runner
- `run-complete-import-selective.sh` - Selective component import
- `run-import-enhanced.sh` - Enhanced import runner

### Purge Scripts (5 files)
- `purge-prod-client.js` - Production client purge
- `purge-prod-client-selective.js` - Selective prod purge
- `purge-dev-client-selective.js` - Selective dev purge
- `purge-dev-complete.cjs` - Complete dev purge
- `purge-selective.cjs` - Selective purge

### Legacy Import Scripts (10 files + 5 backups)
- `import-categories-vendors-with-crud.js`
- `import-transactions-with-crud.js`
- `import-units-with-crud.js`
- `import-users-with-crud.js`
- `import-yearend-balances.js`
- Plus `.backup` versions of each

### Modern/Enhanced Import Scripts (10 files)
- `import-categories-vendors-modern.js`
- `import-transactions-modern.js`
- `import-units-modern.js`
- `import-users-modern.js`
- `import-yearend-balances-modern.js`
- `import-transactions-enhanced.js`
- `import-units-enhanced.js`
- `import-hoa-dues-enhanced.js`
- `import-yearend-balances-enhanced.js`
- `import-hoa-dues-modern.js`

### Debug/Test Scripts (6 files)
- `debug-import.js`
- `debug-units-import.js`
- `test-mtc-state.js`
- `test-units-import.js`
- `run-units-debug.js`
- `check-mtc-state.js`

### Migration Scripts (5 files)
- `execute-migration.js`
- `init-migration.js`
- `prepare-migration.js`
- `prepare-user-mapping.js`
- `migrate-exchange-rates.sh`

### Export/Backup Scripts (3 files)
- `export-client.js`
- `export-client-complete.js`
- `backup-prod-client.js`

### Validation/Analysis Scripts (3 files)
- `validate-hoa-transaction-links.js`
- `verify-migration.js`
- `analyze-client-dynamic.js`

### Documentation (11 files)
- `IMPORT_GUIDE.md`
- `SELECTIVE_IMPORT_GUIDE.md`
- `SELECTIVE_IMPORT_README.md`
- `MODERN_IMPORT_SCRIPTS.md`
- `HOA_DUES_IMPORT_LOGIC.md`
- `IMPORT_LOGIC_DOCUMENTATION.md`
- `TRANSACTION_IMPORT_LOGIC.md`
- `DATE_HANDLING_GUIDE.md`
- `MTC_IMPORT_TEST_REPORT.md`
- `Phase_1_Date_Analysis_Report.md`
- `test-import-report.md`

### Template Files (2 files)
- `client-config-template.json`
- `config-template.json`

## Files NOT Archived (Still Active)

The following files were **kept** because they may still be used by the UI system or for other purposes:

1. `create-default-accounts.js` - Account creation utility
2. `create-yearend-snapshot.js` - Year-end balance snapshots
3. `setup-firebase-config.js` - Firebase configuration
4. `import-config.js` - Import configuration helper
5. `create-firebase-users.js` - User creation utility
6. `README.md` - Main documentation (should be updated)
7. `import-dependencies.json` - Dependency tracking

## How to Use the New UI-Based System

### For Imports:
1. Go to **Settings → Import Management**
2. Upload your data files to Firebase Storage
3. Preview the client data (reads `Client.json`)
4. Click **Import** to onboard the client

### For Purges:
1. Go to **Settings → Import Management**
2. Select the client to purge
3. Choose **Dry Run** or **Live Run**
4. Click **Purge** to delete all client data

### Backend Routes:
- `POST /api/admin/import/preview` - Preview client data
- `POST /api/admin/import/onboard` - Onboard new client
- `POST /api/admin/import/:clientId/purge` - Purge client data
- `GET /api/admin/import/:clientId/progress` - Check progress

### Backend Controllers:
- `backend/controllers/importController.js` - Main import logic
- `backend/services/importService.js` - Import service layer
- `backend/routes/import.js` - API routes

## Data File Format Differences

### Legacy System (Archived)
```bash
# Command line usage
NODE_ENV=prod ./run-complete-import.sh MTC ../../MTCdata

# Expected files in data directory:
- client-config.json  ← lowercase, hyphenated
- Config.json
- Transactions.json
- etc.
```

### UI System (Current)
```bash
# Web UI usage
1. Upload files to Firebase Storage
2. Use web interface

# Expected files:
- Client.json  ← Capital C, no hyphen
- Config.json
- Transactions.json
- etc.
```

## If You Need to Restore

If you need to use the legacy scripts again:

1. Copy the needed files back to `scripts/client-onboarding/`
2. Install dependencies if needed: `npm install`
3. Run the scripts as before
4. Remember they expect `client-config.json` format

## Questions?

- Check the updated `README.md` in parent directory
- Review `backend/controllers/importController.js` for current logic
- Look at UI component: `frontend/sams-ui/src/components/Settings/ImportManagement.jsx`

---

**Archive Total:** ~60 files  
**Archive Size:** Check with `du -sh` command  
**Safe to Delete:** After 90 days if no issues found

